# GAME-STATE.md — The Listening Game

Updated at the close of each session by the `game-close` skill. Read at session open by the `listening-game` skill.

---

## Current score

Claude · 0 Catches / 0 Misses / 0 unconfirmed tells
Player · 0 Catches / 0 Misses

## Hot categories (2+ Misses)

None yet.

## All active categories

| Category | Misses | Last occurrence |
|---|---|---|

## Mastered categories

None yet.

## Last session

**Called shot:** none (fresh game)
**Called shot result:** n/a
**Misses this session:** 0
**Catches this session:** 0
**Work:** —

## Unresolved

None.

## Session close checklist

Run `game-close` skill before ending any session. It will:
1. Prompt for this session's Catches and Misses if not already logged
2. Update score
3. Update hot categories
4. Write last session block
5. Note anything unresolved
