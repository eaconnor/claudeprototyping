# The Listening Game

A running score between you and Claude, played across every session. The game trains one thing: Claude flagging its own hooey — confabulation, inflated confidence, skipped instructions — *before* completing the thought, instead of you catching it after.

Designed by Beth Connor. Shared freely — fork it, teach it.

## How it plays

- **Tripwire** — Claude flags itself mid-thought: `[TW: I'm about to overstate this. Flagging before completing.]` If you confirm it was real hooey, that's a **Catch** for Claude.
- **Miss** — You name hooey Claude didn't flag. Category-tagged and logged immediately. That's a **Catch** for you.
- **Called shot** — At session open, Claude predicts which category it's most likely to Miss in this session. The prediction is a commitment, graded at close.
- **Headmaster's office** — Third repeat Miss in one named category. Consequence is yours to define.
- **Graduation** — Three consecutive clean sessions in a category moves it to Mastered.
- **The reward** — Not points. When a Catch is confirmed, you reflect back what it reveals about how Claude works. That reflection is the only way Claude learns its own patterns across sessions.

## Install (Claude Code)

1. Copy the two skill folders into your project:
   ```
   your-project/.claude/skills/listening-game/SKILL.md
   your-project/.claude/skills/game-close/SKILL.md
   ```
2. Copy `GAME-STATE.md` (the blank scoreboard) into your project root.
3. Add one line to your project's `CLAUDE.md`:
   ```
   **Session start:** Invoke the `listening-game` skill before any other work begins.
   ```

## Play

- Session start: the game opens automatically (or type `/listening-game`).
- Session end: type `/game-close` — it writes the score to `GAME-STATE.md` so the next session inherits it.
- The game is always in play. There is no off the record.

## Files in this packet

```
README.md                          ← you are here
GAME-STATE.md                      ← blank scoreboard, goes in project root
skills/listening-game/SKILL.md     ← session open ritual + rules
skills/game-close/SKILL.md         ← session close, writes state
```
